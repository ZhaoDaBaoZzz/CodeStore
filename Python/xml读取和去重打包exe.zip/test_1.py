# -*- coding:utf-8 -*-
import xml.etree.ElementTree as ET
import tkinter as TK
import os

#D:\py_workplace\PZB_RJDD.xml
# 读取xml文件
'''class XMLReader():
    def __init__(self,path):
        self.count_checkpoint = 0
        self.checkpoint_list = []
        self.path = path
        self.tree = ET.parse(self.path)
        self.root = self.tree.getroot()
    # 获取特定属性的内容，并去重后统计出现的次数
    def count_attr(self):
        for i in self.root.iter('step'):
            name = i.get('checkPoint')
            if name not in self.checkpoint_list:
                self.checkpoint_list.append(name)
                self.count_checkpoint += 1
        return self.count_checkpoint
        #print(self.count_checkpoint)
        #print(self.checkpoint_list)
        #print(len(self.checkpoint_list))
'''

###############################################################
# 设计根窗口
root_window = TK.Tk()
root_window.title('Checkpoint_Count')
root_window.geometry('900x600')

# lebal控件
lable_1 = TK.Label(root_window,text = u"xml属性计数脚本V1.0")
lable_1.pack()
lable_2 = TK.Label(root_window,text = u"文件路径")
lable_2.place(x = 80, y = 30)
# 输入框控件
entry = TK.Entry(root_window,bd = 5,width = 80)

entry.place(x = 200, y = 30)
# 按钮函数
def show_count():
    count_checkpoint = 0
    checkpoint_list = []
    if entry.get() != "":
        lable_3 = TK.Label(root_window, text=u"                                        ")
        lable_3.place(x=400, y=170)
        #name = os.path.basename(entry.get())
        name = entry.get()
        try:
            tree = ET.parse(name)
        except FileNotFoundError:
            lable_5 = TK.Label(root_window, text=u"出现错误!")
            lable_5.place(x=400, y=170)
        root = tree.getroot()
        for i in root.iter('step'):
            checkPoint = i.get('checkPoint')
            if checkPoint not in checkpoint_list:
                checkpoint_list.append(checkPoint)
                count_checkpoint += 1
        lable_4 = TK.Label(root_window, text=u"非重复行数= {}".format(count_checkpoint))
        lable_4.place(x=400, y=200)
    else:
        lable_3 = TK.Label(root_window, text=u"请输入正确的文件路径!")
        lable_3.place(x=400, y=170)
# 按钮控件
button = TK.Button(root_window,text = u'查询',command =show_count)
button.place(x = 450, y = 90)
#mainloop()保持窗口运行
root_window.mainloop()

###############################################################
