# -*- coding: utf-8 -*-
from shutil import copy
import tkinter as TK
import os
import xlrd
import xlwt
###############################################################
# 设计根窗口
root_window = TK.Tk()
root_window.title('CheckExcel')
root_window.geometry('900x600')

excel_path = "example.xlsx"
excel_path_1 = "C:\excel.txt"

# lebal控件
lable_1 = TK.Label(root_window,text = u"Excel单列去重脚本V1.0")
lable_1.pack()
lable_2 = TK.Label(root_window,text = u"文件路径")
lable_2.place(x = 80, y = 30)
lable_7 = TK.Label(root_window,text = u"输出去重后的数据列在C://根目录的excel.txt")
lable_7.place(x = 350, y = 220)
# 输入框控件
entry = TK.Entry(root_window,bd = 5,width = 80)

entry.place(x = 200, y = 30)
# 按钮函数
def show_count():
    check_list = []
    if entry.get() != "":
        lable_3 = TK.Label(root_window, text=u"                                        ")
        lable_3.place(x=400, y=170)
        #name = os.path.basename(entry.get())
        name = entry.get()
        try:
            # 打开文件，获取excel文件的workbook（工作簿）对象
            data = xlrd.open_workbook(name, encoding_override="utf-8")
        except FileNotFoundError:
            lable_5 = TK.Label(root_window, text=u"出现错误!")
            lable_5.place(x=400, y=170)
        # 获取sheet对象
        table = data.sheets()[0]#选定表
        with open(excel_path_1, 'w') as excel_write:
            for i in table.col_values(0):
                if i not in check_list:
                    check_list.append(i)
                    excel_write.writelines(i + "\n")
    else:
        lable_6 = TK.Label(root_window, text=u"请输入正确的文件路径!")
        lable_6.place(x=400, y=170)
# 按钮控件
button = TK.Button(root_window,text = u'合并',command =show_count)
button.place(x = 450, y = 90)
#mainloop()保持窗口运行
root_window.mainloop()

###############################################################
