# -*- coding: utf-8 -*-
from shutil import copy

import xlrd
import xlwt

excel_path = "example.xlsx"
excel_path_1 = "example1.txt"

# 打开文件，获取excel文件的workbook（工作簿）对象

data = xlrd.open_workbook(excel_path, encoding_override="utf-8")

# 获取sheet对象
all_sheet = data.sheets()

# 循环遍历每个sheet对象
sheet_name = []
sheet_row = []
sheet_col = []
for sheet in all_sheet:
    sheet_name.append(sheet.name)
print("该Excel共有{0}个sheet,当前sheet名称为{1},该sheet共有{2}行,{3}列".format(len(all_sheet), sheet.name, sheet.nrows, sheet.ncols))

print(sheet.col_values(0))  # 获取指定列的数据
with open(excel_path_1,'w') as excel_write:
    for i in sheet.col_values(0):
        #print(i + '_01')
        excel_write.writelines(i + '_06' + "\n")
'''
for each_col in range(sheet.ncols):  # 依次获得每一列的数据
    print("当前为%s列：" % each_col)
    print(sheet.col_values(each_col), type(sheet.col_values(each_col)))
'''